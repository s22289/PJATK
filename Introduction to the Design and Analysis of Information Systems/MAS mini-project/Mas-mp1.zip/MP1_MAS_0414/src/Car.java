
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Car implements Serializable {

    // mandatory
    private long id;
    // mandatory
    private String brand;
    // mandatory
    private String model;
    // mandatory
    private int year;

    // optional
    private String name;

    // class attribute
    private static int MAX_BRAND_LENGTH = 20;

    // multi-value attribute
    private List<String> features;

    // complex attribute
    private Measurements measurements;

    // extent
    private static List<Car> extent = new ArrayList<>();

    public static final String DATA_DAT = "data.dat";

    public Car(long id, String name, String brand, String model, int year, List<String> features, Measurements measurements) throws Exception {
        if (brand == null || model == null || year < 0) {
            throw new IllegalArgumentException("Invalid car information.");
        }

        if(features != null){
            this.features = features;
        }

        this.id = id;
        this.name = name;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.measurements = measurements;
        extent.add(this);
    }

    // extent persistence
    public static void saveExtent(ObjectOutputStream stream) throws IOException {
        stream.writeObject(extent);
    }

    // extent persistence
    public static void loadExtent(ObjectInputStream stream) throws IOException, ClassNotFoundException {
        extent = (List<Car>) stream.readObject();
    }

    // derived attribute
    public String getCarInfo() {
        return this.brand + " " + this.model + " (" + this.year + ")";
    }

    // class method
    public static List<Car> getCarsByModel(String model) {
        if (model == null || model.trim().isEmpty()) {
            throw new IllegalArgumentException("Model name must be provided");
        }
        List<Car> result = new ArrayList<>();
        for (Car car : extent) {
            if (car.getModel().equals(model)) {
                result.add(car);
            }
        }
        return result;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        if (id < 0) {
            throw new IllegalArgumentException("ID must be a positive number");
        }
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private static boolean invalidModelLength(String model) {
        return model.length() > MAX_BRAND_LENGTH;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        if (model == null || model.isEmpty()) {
            throw new IllegalArgumentException("Model name cannot be null or empty.");
        }
        if (!model.matches("^[a-zA-Z0-9\\s]+$")) {
            throw new IllegalArgumentException("Model name can only contain letters, numbers, and spaces.");
        }
        if (invalidModelLength(model.trim())) {
            throw new IllegalArgumentException("Model name cannot be longer than 15 characters.");
        }
        this.model = model;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        if (brand == null || brand.isEmpty()) {
            throw new IllegalArgumentException("Brand name cannot be null or empty.");
        }
        this.brand = brand;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year < 0) {
            throw new IllegalArgumentException("Year must be a positive number.");
        }
        this.year = year;
    }

    public List<String> getFeatures() {
        return Collections.unmodifiableList(features);
    }

    public void addFeature(String feature) {
        if (feature == null || feature.trim().isEmpty()) {
            throw new IllegalArgumentException("Feature cannot be null or empty.");
        }
        if (this.features.contains(feature)) {
            throw new IllegalArgumentException("Feature already exists.");
        }
        this.features.add(feature.trim());
    }

    public void removeFeature(String feature) {
        if (feature == null || feature.trim().isEmpty()) {
            throw new IllegalArgumentException("Feature cannot be null or empty.");
        }
        if (!this.features.contains(feature)) {
            throw new IllegalArgumentException("Feature does not exist.");
        }
        if (this.features.size() - 1 <= 0) {
            System.out.println("Cannot remove the last element");
        }
        this.features.remove(feature.trim());
    }

    public Measurements getMeasurements() {
        return measurements;
    }

    public void setMeasurements(Measurements Mmasurements) {
        this.measurements = measurements;
    }

    public static List<Car> getExtent() {
        return Collections.unmodifiableList(extent);
    }

    public static int getMaxModelLength() {
        return MAX_BRAND_LENGTH;
    }

    public static void setMaxModelLength(int maxModelLength) {
        if (maxModelLength > 15) {
            throw new IllegalArgumentException("Max model length cannot be longer than 15.");
        }
        MAX_BRAND_LENGTH = maxModelLength;
    }

    @Override
    public String toString() {
        return "Car{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", year=" + year +
                ", features=" + features +
                ", measurements=" + measurements +
                '}';
    }
}
