
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        try {
            // Create an instance of Measurements for the car
            Measurements measurements = new Measurements(16.4, 56.9, 7.2);

            // Create an instance of Car
            Car car1 = new Car(1, "Tesla Model S", "Tesla", "Model S", 2023,
                    new ArrayList<String>(Arrays.asList("Electric", "Autopilot")), measurements);

            // Test getters and setters
            System.out.println(car1.getName()); // Output: Tesla Model S
            car1.setName("Tesla Model X");

            System.out.println(car1.getName()); // Output: Tesla Model X
            System.out.println(car1.getMeasurements());

            // Test getCarsByModel()
            List<Car> matchingCars = Car.getCarsByModel("Model S");
            for (Car car : matchingCars) {
                System.out.println(car.getName() + " " + car.getModel());
            }

            // Test addFeature() and removeFeature()
            car1.addFeature("AWD");
            System.out.println(car1.getFeatures()); // Output: [Electric, Autopilot, AWD]
            car1.removeFeature("AWD");
            System.out.println(car1.getFeatures()); // Output: [Electric, Autopilot]

            // Save the car extent to a file
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(Car.DATA_DAT));
            Car.saveExtent(oos);
            oos.close();

            // Load the car extent from the file
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(Car.DATA_DAT));
            Car.loadExtent(ois);
            ois.close();

            // Test getExtent()
            List<Car> extent = Car.getExtent();
            for (Car car : extent) {
                System.out.println(car.getName() + " " + car.getModel()); // Output: Tesla Model X Model S
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
