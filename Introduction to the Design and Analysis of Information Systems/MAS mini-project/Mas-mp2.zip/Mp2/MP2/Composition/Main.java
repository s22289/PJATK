package MP2.Composition;


public class Main {
    public static void main(String[] args) throws Exception {
        // Creating project managers
        ProjectManager p1 = new ProjectManager("Mobile App Project Manager");
        ProjectManager p2 = new ProjectManager("Web Development Project Manager");

        // Creating task managers associated with project managers
        TaskManager t1 = TaskManager.createTask(p1, "Design login screen");
        TaskManager t2 = TaskManager.createTask(p1, "Implement user registration");
        TaskManager t3 = TaskManager.createTask(p1, "Integrate payment gateway");
        TaskManager t4 = TaskManager.createTask(p2, "Set up server environment");


        System.out.println("***********************************************************");
        System.out.println("Project 1");
        System.out.println("***********************************************************");
        p1.addTask(t1);
        p1.addTask(t2);
        p1.addTask(t3);
        System.out.println(p1);

        System.out.println("***********************************************************");
        System.out.println("Project 2");
        System.out.println("***********************************************************");
        p2.addTask(t4);
        System.out.println(p2);

        System.out.println("***********************************************************");
        System.out.println("Project == null");
        System.out.println("***********************************************************");
        ProjectManager np = null;
        TaskManager t5 = TaskManager.createTask(np, "Empty Design");
        System.out.println(np);
    }
}
