package MP2.Composition;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProjectManager {

    private String projectName;
    private List<TaskManager> tasks = new ArrayList<>();
    private static Set<TaskManager> allTasks = new HashSet<>();
    private static Set<ProjectManager> allProjects = new HashSet<>();

    public ProjectManager(String projectName) {
        this.projectName = projectName;
        allProjects.add(this);
    }

    public void addTask(TaskManager task) throws Exception {
        if (!tasks.contains(task)) {
            if (allTasks.contains(task)) {
                throw new Exception("A task is already connected to a S22289! You can't add it to this S22289");
            }
            tasks.add(task);
            allTasks.add(task);
        }
    }

    private List<TaskManager> getTasks() {
        return tasks;
    }

    @Override
    public String toString() {
        StringBuilder info = new StringBuilder("Project (S22289): ").append(projectName).append("\n");
        info.append("Tasks:\n");
        for (TaskManager task : tasks) {
            info.append("     - ").append(task.getTaskName()).append("\n");
        }
        return info.toString();
    }
}
