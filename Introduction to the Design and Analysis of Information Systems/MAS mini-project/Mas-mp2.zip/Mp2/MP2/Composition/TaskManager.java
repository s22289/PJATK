package MP2.Composition;

public class TaskManager {

    private String taskName;
    private ProjectManager whole;

    private TaskManager(ProjectManager whole, String taskName) {
        this.taskName = taskName;
        this.whole = whole;
    }

    public static TaskManager createTask(ProjectManager whole, String taskName) throws Exception {
        if (whole == null) {
            throw new Exception("The Project does not exist, You cannot create a part for it");
        }
        TaskManager task = new TaskManager(whole, taskName);
        whole.addTask(task);
        return task;
    }

    String getTaskName() {
        return taskName;
    }
}
