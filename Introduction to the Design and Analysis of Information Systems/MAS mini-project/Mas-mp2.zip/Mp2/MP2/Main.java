package MP2;

import MP2.Binary.Athlete;
import MP2.Binary.Workout;
import MP2.Qualified.*;
import MP2.Composition.*;

import MP2.WAttribute.*;

public class Main {
    public static void main(String[] args) throws Exception {

        // Binary Relationships - Many to Many: Athlete - Workout

        // Creating Athlete objects
        Athlete a1 = new Athlete("John", "Doe");
        Athlete a2 = new Athlete("Jane", "Smith");
        Athlete a3 = new Athlete("Michael", "Johnson");

        // Creating Workout objects
        Workout w1 = new Workout("Push-ups", "Moderate", "Chest, Arms");
        Workout w2 = new Workout("Squats", "Hard", "Legs, Glutes");
        Workout w3 = new Workout("Planks", "Easy", "Core");

        // Associating Athlete with Workouts
        a1.addWorkout(w2);
        a1.addWorkout(w3);
        a2.addWorkout(w1);
        a2.addWorkout(w2);
        a3.addWorkout(w3);

        // Displaying information about athletes
        System.out.println("Information about athletes:");
        System.out.println();
        System.out.println(a1);
        System.out.println();
        System.out.println(a2);
        System.out.println();
        System.out.println(a3);

        // Displaying information about workouts
        System.out.println("Information about workouts:");
        System.out.println();
        System.out.println(w1);
        System.out.println();
        System.out.println(w2);
        System.out.println();
        System.out.println(w3);

        // Composition Relationships

        // Creating Project Managers
        ProjectManager p1 = new ProjectManager("Mobile App Project Manager");
        ProjectManager p2 = new ProjectManager("Web Development Project Manager");

        // Creating TaskManagers associated with Project Managers
        TaskManager t1 = TaskManager.createTask(p1, "Design login screen");
        TaskManager t2 = TaskManager.createTask(p1, "Implement user registration");
        TaskManager t3 = TaskManager.createTask(p1, "Integrate payment gateway");
        TaskManager t4 = TaskManager.createTask(p2, "Set up server environment");

        // First project
        System.out.println("***********************************************************");
        System.out.println("Project 1");
        System.out.println("***********************************************************");
        p1.addTask(t1);
        p1.addTask(t2);
        p1.addTask(t3);
        System.out.println(p1);

        // Second project
        System.out.println("***********************************************************");
        System.out.println("Project 2");
        System.out.println("***********************************************************");
        p2.addTask(t4);
        System.out.println(p2);

        // Attempting to add a task to a non-existent project (null)
        System.out.println("***********************************************************");
        System.out.println("Project == null");
        System.out.println("***********************************************************");
        ProjectManager np = null;
        TaskManager t5 = TaskManager.createTask(np, "Empty Design");
        System.out.println(np);

        // Qualified Relationships

        // Creating Developers
        Developer d1 = new Developer("Icardi", "Doe");
        Developer d2 = new Developer("Alice", "Taha");

        // Creating ApplicationManagers
        ApplicationManager am1 = new ApplicationManager("EHR2024", "Electronic Health Records");
        ApplicationManager am2 = new ApplicationManager("POS7458", "Point of Sale System");
        ApplicationManager am3 = new ApplicationManager("CMS3698", "Content Management System");

        // Associating Developers with Applications
        d1.setApplication(am1);
        d1.setApplication(am3); // Unable to add the same developer to one application twice
        d2.setApplication(am1);
        d2.setApplication(am2);

        System.out.println("*****************************************************");
        System.out.println("Developer 1:");
        System.out.println("*****************************************************");
        System.out.println(d1);

        System.out.println("*****************************************************");
        System.out.println("Developer 2:");
        System.out.println("*****************************************************");
        System.out.println(d2);

        System.out.println("*****************************************************");
        System.out.println("\t\t\t Searching map by key:");
        System.out.println("*****************************************************");
        System.out.println(d1.findApplication("EHR2024"));

        // Uncomment the following lines to display information about applications am1 and am2

        // Association with Attribute

        Exercise e4 = new Exercise("Crunches", "easy");
        Exercise e5 = new Exercise("100 m running intervals", "hard");
        Exercise e6 = new Exercise("Burpees", "moderate");

        // Creating Workouts
        MP2.WAttribute.Workout ww1 = new MP2.WAttribute.Workout("workout1");
        MP2.WAttribute.Workout ww2 = new MP2.WAttribute.Workout("workout2");
        MP2.WAttribute.Workout ww3 = new MP2.WAttribute.Workout("workout3");

        // Creating Workout_Exercise associations
        Workout_Exercise se1 = new Workout_Exercise(10, e6, ww2);  // Crunches - 4 sets
        Workout_Exercise se2 = new Workout_Exercise(30, e4, ww1);  // Burpees - 3 sets
        Workout_Exercise se3 = new Workout_Exercise(5, e5, ww3);   // Running - 6 sets

        // Displaying information about Workout_Exercise associations
        System.out.println("*****************************************************");
        System.out.println("\t\t\t\t Workout_Exercise Associations:");
        System.out.println("*****************************************************");
        System.out.println(se1);
        System.out.println(se2);
        System.out.println(se3);
        System.out.println();

        // Displaying information about Exercises
        System.out.println("*****************************************************");
        System.out.println("\t\t\t\t\tExercises:");
        System.out.println("*****************************************************");
        System.out.println(e4);
        System.out.println(e5);
        System.out.println(e6);
        System.out.println();

        // Displaying information about Workouts
        System.out.println("----------------------------------------------------");
        System.out.println("\t\t\t\t\t Workouts:");
        System.out.println("----------------------------------------------------");
        System.out.println(ww1);
        System.out.println(ww2);
        System.out.println(ww3);
        System.out.println();

        // Removing the association between Workout and Exercise
        System.out.println("*****************************************************");
        System.out.println("   Removing association between Workout and Exercise");
        System.out.println("*****************************************************");
        se1.removeAssociation();
        System.out.println(se1);
    }
}
