package MP2.Qualified;


public class ApplicationManager {

    private String uniqueSymbol;
    private String nameOfApplication;
    private Developer developer;

    public ApplicationManager(String uniqueSymbol, String nameOfApplication) {
        this.uniqueSymbol = uniqueSymbol;
        this.nameOfApplication = nameOfApplication;
    }

    public String getUniqueSymbol() {
        return uniqueSymbol;
    }

    public void setUniqueSymbol(String uniqueSymbol) {
        this.uniqueSymbol = uniqueSymbol;
    }

    public String getNameOfApplication() {
        return nameOfApplication;
    }

    public void setNameOfApplication(String nameOfApplication) {
        this.nameOfApplication = nameOfApplication;
    }

    public Developer getDevelopers() {
        return developer;
    }

    public void setDeveloper(Developer newDeveloper) {
        this.developer = newDeveloper;
    }

    @Override
    public String toString() {
        return "\n     - Application Symbol: " + uniqueSymbol + ",  Name: " + nameOfApplication;
    }
}
