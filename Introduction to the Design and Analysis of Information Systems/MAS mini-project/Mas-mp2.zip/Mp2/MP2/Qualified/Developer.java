package MP2.Qualified;

import java.util.HashMap;
import java.util.Map;

public class Developer {

    private String firstName;
    private String lastName;
    private Map<String, ApplicationManager> applicationMap = new HashMap<>();

    public Developer(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Map<String, ApplicationManager> getApplicationMap() {
        return applicationMap;
    }

    public void setApplicationMap(Map<String, ApplicationManager> applicationMap) {
        this.applicationMap = applicationMap;
    }

    public void setApplication(ApplicationManager newApplication) throws Exception {
        if (!applicationMap.containsKey(newApplication.getUniqueSymbol())) {
            applicationMap.put(newApplication.getUniqueSymbol(), newApplication);
            newApplication.setDeveloper(this);
        } else {
            throw new Exception("Unable to add application with uniqueSymbol " + newApplication.getUniqueSymbol());
        }
    }

    public ApplicationManager findApplication(String uniqueSymbol) throws Exception {
        if (!applicationMap.containsKey(uniqueSymbol)) {
            System.err.println("Application with symbol: " + uniqueSymbol + " does not exist");
        }
        return applicationMap.get(uniqueSymbol);
    }

    @Override
    public String toString() {
        StringBuilder info = new StringBuilder("Developer: ").append(firstName).append(" ").append(lastName);
        for (Map.Entry<String, ApplicationManager> entry : applicationMap.entrySet()) {
            info.append(entry.getValue());
        }
        return info.toString();
    }
}
