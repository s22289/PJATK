package MP2.Qualified;


public class Main {
    public static void main(String[] args) throws Exception {

        Developer d1 = new Developer("Icardi", "Doe");
        Developer d2 = new Developer("Alice", "Taha");

        ApplicationManager a1 = new ApplicationManager("EHR2024", "Electronic Health Records");
        ApplicationManager a2 = new ApplicationManager("POS7458", "Point of Sale System");
        ApplicationManager a3 = new ApplicationManager("CMS3698", "Content Management System");

        d1.setApplication(a1);
        d1.setApplication(a3);

        d2.setApplication(a1);
        d2.setApplication(a2);

        System.out.println("*****************************************************");
        System.out.println("Developer 1:");
        System.out.println("*****************************************************");
        System.out.println(d1);

        System.out.println("*****************************************************");
        System.out.println("Developer 2:");
        System.out.println("*****************************************************");
        System.out.println(d2);

        System.out.println("*****************************************************");
        System.out.println("\t\t\t Searching map by key:");
        System.out.println("*****************************************************");
        System.out.println(d1.findApplication("EHR2024"));
    }
}
