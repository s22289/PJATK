package MP2.Binary;

import java.util.ArrayList;
import java.util.List;

public class Workout {

    private String workoutName;
    private String intensityLevel;
    private String musclesTrained;
    private List<Athlete> athletes = new ArrayList<>();

    public Workout(String workoutName, String intensityLevel, String musclesTrained) {
        this.workoutName = workoutName;
        this.intensityLevel = intensityLevel;
        this.musclesTrained = musclesTrained;
    }

    public void addAthlete(Athlete newAthlete) {
        if (!athletes.contains(newAthlete)) {
            athletes.add(newAthlete);
            newAthlete.addWorkout(this);
        }
    }

    @Override
    public String toString() {
        String info = "Workout:\n" +
                "Name: " + workoutName + "\nIntensity Level: " + intensityLevel + "\nMuscles Trained: " + musclesTrained + "\nAthletes:\n";

        for (Athlete a : athletes) {
            info += "- " + a.getFirstName() + " " + a.getLastName() + "\n";
        }
        return info;
    }

    public String getWorkoutName() {
        return workoutName;
    }

    public void setWorkoutName(String workoutName) {
        this.workoutName = workoutName;
    }

    public String getIntensityLevel() {
        return intensityLevel;
    }

    public void setIntensityLevel(String intensityLevel) {
        this.intensityLevel = intensityLevel;
    }

    public String getMusclesTrained() {
        return musclesTrained;
    }

    public void setMusclesTrained(String musclesTrained) {
        this.musclesTrained = musclesTrained;
    }
}
