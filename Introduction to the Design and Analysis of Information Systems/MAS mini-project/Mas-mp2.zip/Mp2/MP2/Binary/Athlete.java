package MP2.Binary;

import java.util.ArrayList;
import java.util.List;

public class Athlete {

    private String firstName;
    private String lastName;
    private List<Workout> performedWorkouts = new ArrayList<>();

    public Athlete(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public void addWorkout(Workout newWorkout) {
        if (!performedWorkouts.contains(newWorkout)) {
            performedWorkouts.add(newWorkout);
            newWorkout.addAthlete(this);
        }
    }

    @Override
    public String toString() {
        String info = "Athlete:\n" +
                firstName + " " + lastName + "\nWorkouts:\n";

        for (Workout w : performedWorkouts) {
            info += "- " + w.getWorkoutName() + "\n";
        }
        return info;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
