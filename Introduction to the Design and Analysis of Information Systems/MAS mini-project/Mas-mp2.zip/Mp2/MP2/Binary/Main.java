package MP2.Binary;


public class Main {
    public static void main(String[] args) {

        Athlete a1 = new Athlete("John", "Doe");
        Athlete a2 = new Athlete("Jane", "Smith");
        Athlete a3 = new Athlete("Michael", "Johnson");

        Workout w1 = new Workout("Push-ups", "Moderate", "Chest, Arms");
        Workout w2 = new Workout("Squats", "Hard", "Legs, Glutes");
        Workout w3 = new Workout("Planks", "Easy", "Core");

        a1.addWorkout(w2);
        a1.addWorkout(w3);
        a2.addWorkout(w1);
        a2.addWorkout(w2);

        a3.addWorkout(w3);

        System.out.println("Information about athletes:");
        System.out.println();
        System.out.println(a1);
        System.out.println();
        System.out.println(a2);
        System.out.println();
        System.out.println(a3);

        System.out.println();
        System.out.println("Information about workouts:");
        System.out.println();
        System.out.println(w1);
        System.out.println();
        System.out.println(w2);
        System.out.println();
        System.out.println(w3);
    }
}
