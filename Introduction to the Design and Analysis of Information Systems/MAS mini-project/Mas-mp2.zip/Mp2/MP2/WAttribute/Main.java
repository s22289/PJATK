package MP2.WAttribute;

public class Main {

    public static void main(String[] args) {
        // Creating workouts
        Workout w1 = new Workout("Full Body");
        Workout w2 = new Workout("Leg Day");
        Workout w3 = new Workout("Core Strengthening");

        // Creating exercises
        Exercise e1 = new Exercise("Crunches", "easy");
        Exercise e2 = new Exercise("Squats", "hard");
        Exercise e3 = new Exercise("Planks", "moderate");

        // Associating exercises with workouts
        w1.addExercise(e1);
        w1.addExercise(e2);
        w2.addExercise(e2);
        w2.addExercise(e3);
        w3.addExercise(e1);
        w3.addExercise(e3);

        // Displaying information about workouts
        System.out.println("****************************************************");
        System.out.println("Workouts:");
        System.out.println("****************************************************");
        System.out.println(w1);
        System.out.println(w2);
        System.out.println(w3);

        // Removing the association between Exercise and Workout
        System.out.println("****************************************************");
        System.out.println("Removing association between Exercise and Workout");
        System.out.println("****************************************************");
        e1.removeAssociation();
        System.out.println(w3);
    }
}
