package MP2.WAttribute;

public class Workout_Exercise {

    // Number of reps for the exercise in the workout
    private int numberOfReps;

    // Exercise associated with the workout_exercise
    private Exercise exercise;

    // Workout associated with the workout_exercise
    private Workout workout;

    // Constructor to initialize workout_exercise with the number of reps, an exercise, and a workout
    public Workout_Exercise(int numberOfReps, Exercise exercise, Workout workout) {
        this.numberOfReps = numberOfReps;
        this.exercise = exercise;
        this.workout = workout;

        // Adding Inverse Associations
        exercise.addWorkoutExercise(this);
        workout.addExercise(exercise);
    }

    // toString method to return a string representation of the workout_exercise
    @Override
    public String toString() {
        return "Number of Reps: " + numberOfReps + "\n" +
                "Exercise: " + exercise.getExerciseName() + "\n" +
                "Workout: " + workout.getWorkoutName();
    }

    // Method to remove the association between exercise and workout
    public void removeAssociation() {
        exercise = null;
        workout.removeExercise(exercise);
        workout = null;
    }
}
