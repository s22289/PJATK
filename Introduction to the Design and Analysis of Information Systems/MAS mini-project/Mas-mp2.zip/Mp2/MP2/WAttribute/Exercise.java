package MP2.WAttribute;

import java.util.ArrayList;
import java.util.List;

public class Exercise {

    // Name of the exercise
    private String exerciseName;

    // Difficulty level of the exercise
    private String difficulty;

    // List of workout_exercises associated with the exercise
    private List<Workout_Exercise> workoutExercises = new ArrayList<>();

    // Constructor to initialize the exercise with a name and difficulty
    public Exercise(String exerciseName, String difficulty) {
        this.exerciseName = exerciseName;
        this.difficulty = difficulty;
    }

    // Method to add a workout_exercise to the list of workout_exercises
    void addWorkoutExercise(Workout_Exercise newWorkoutExercise) {
        if (!workoutExercises.contains(newWorkoutExercise)) {
            workoutExercises.add(newWorkoutExercise);
        }
    }

    // toString method to return a string representation of the exercise
    @Override
    public String toString() {
        String info = "Exercise: " + exerciseName + "\n" +
                "Difficulty: " + difficulty + "\n";
        return info;
    }

    // Method to remove the association between exercise and workout
    void removeAssociation() {
        for (Workout_Exercise workoutExercise : workoutExercises) {
            workoutExercise.removeAssociation();
        }
        workoutExercises.clear();
    }

    // Getter for the exercise name
    String getExerciseName() {
        return exerciseName;
    }

    // Getter for the exercise difficulty
    String getDifficulty() {
        return difficulty;
    }
}
