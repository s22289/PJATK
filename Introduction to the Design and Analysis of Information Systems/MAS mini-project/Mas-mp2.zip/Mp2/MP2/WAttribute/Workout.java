package MP2.WAttribute;

import java.util.ArrayList;
import java.util.List;

public class Workout {

    // Name of the workout
    private String workoutName;

    // List of exercises associated with the workout
    private List<Exercise> exercises = new ArrayList<>();

    // Constructor to initialize the workout with a name
    public Workout(String workoutName) {
        this.workoutName = workoutName;
    }

    // Method to add an exercise to the list of exercises
    void addExercise(Exercise newExercise) {
        if (!exercises.contains(newExercise)) {
            exercises.add(newExercise);
        }
    }

    // toString method to return a string representation of the workout
    @Override
    public String toString() {
        String info = "Workout: " + workoutName + "\n";
        for (Exercise exercise : exercises) {
            info += exercise.toString() + "\n";
        }
        return info;
    }

    // Method to remove an exercise from the list of exercises
    void removeExercise(Exercise exerciseForRemoval) {
        if (this.exercises.contains(exerciseForRemoval)) {
            this.exercises.remove(exerciseForRemoval);
            exerciseForRemoval.removeAssociation();
        }
    }

    // Getter for the workout name
    String getWorkoutName() {
        return workoutName;
    }
}
