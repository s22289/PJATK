package Mas_mp3;

import java.util.ArrayList;
import java.util.List;

class MultiaspectCharacter {
    private boolean canSpewFire;
    private boolean canScorch;
    private boolean canEngulf;
    private CharacterTypeEnum type;

    protected MultiaspectCharacter(CharacterTypeEnum type) {
        this.type = type;
        this.setCharacterType(type);
    }

    public boolean isCanSpewFire() {
        return canSpewFire;
    }

    public boolean isCanScorch() {
        return canScorch;
    }

    public boolean isCanEngulf() {
        return canEngulf;
    }

    public CharacterTypeEnum getType() {
        return type;
    }

    public static MultiaspectCharacter createBlazingTypeCharacter(CharacterTypeEnum type) {
        if (type != CharacterTypeEnum.FireSprite)
            throw new IllegalArgumentException("Type is not FireSprite");
        MultiaspectCharacter character = new MultiaspectCharacter(type);
        return character;
    }

    public static MultiaspectCharacter createBurningTypeCharacter(CharacterTypeEnum type) {
        if (type != CharacterTypeEnum.Emberling)
            throw new IllegalArgumentException("Type is not Emberling");
        MultiaspectCharacter character = new MultiaspectCharacter(type);
        return character;
    }

    private void setCharacterType(CharacterTypeEnum characterType) {
        switch (characterType) {
            case FireSprite:
                canSpewFire = true;
                canScorch = true;
                break;
            case Emberling:
                canSpewFire = true;
                canScorch = true;
                break;
            case InfernoDragon:
                canSpewFire = true;
                canScorch = true;
                canEngulf = true;
                break;
            case FireSiren:
                canSpewFire = true;
                break;
            default:
                break;
        }
    }

    @Override
    public String toString() {
        return "Can spew fire: " + canSpewFire + ", Can scorch: " + canScorch + ", Can engulf: " + canEngulf + ", Type: " + type;
    }
}

class MultiaspectCharacterFire extends MultiaspectCharacter {
    private String name;
    private int heat;

    public MultiaspectCharacterFire(String name, int heat) {
        super(CharacterTypeEnum.FireSiren);
        this.name = name;
        this.heat = heat;
    }

    @Override
    public String toString() {
        return super.toString() + ", Name: " + name + ", Heat Level: " + heat;
    }
}

class MultiaspectCharacterBlazing extends MultiaspectCharacter {
    private String name;
    private int flameIntensity;

    public MultiaspectCharacterBlazing(String name, int flameIntensity) {
        super(CharacterTypeEnum.FireSprite);
        this.name = name;
        this.flameIntensity = flameIntensity;
    }

    @Override
    public String toString() {
        return super.toString() + ", Name: " + name + ", Flame Intensity: " + flameIntensity;
    }
}

// Enumeration representing different character types
enum CharacterTypeEnum {
    FireSprite,
    Emberling,
    InfernoDragon,
    FireSiren
}