package Mas_mp3;

public class Mage extends Character { //disjoint inheritance to Character
    private String specialSkill;
    private double skillDamage;

    public Mage(String name, double strength, String weaponType, double hitDamage, double health, String specialSkill, double skillDamage) {
        super(name, strength, weaponType, hitDamage, health);
        this.specialSkill = specialSkill;
        this.skillDamage = skillDamage;
    }


    //Polymorphism - abstract method call
    @Override
    public void attack(Character character) {
        double finalDamage = this.getHitDamage() + this.skillDamage;
        character.takeDamage(finalDamage);
    }

    public String getSpecialSkill() {
        return specialSkill;
    }

    public void setSpecialSkill(String specialSkill) {
        this.specialSkill = specialSkill;
    }

    public double getSkillDamage() {
        return skillDamage;
    }

    public void setSkillDamage(double skillDamage) {
        this.skillDamage = skillDamage;
    }

    @Override
    public String toString() {
        return "Mage{" +
                "specialSkill='" + specialSkill + '\'' +
                ", skillDamage=" + skillDamage +
                '}';
    }
}
