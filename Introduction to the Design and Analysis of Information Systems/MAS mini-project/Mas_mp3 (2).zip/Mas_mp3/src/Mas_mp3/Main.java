package Mas_mp3;

import java.util.ArrayList;
import java.util.List;




public class Main {
    public static void main(String[] args) {
        //Dynamic Inheritance
        System.out.println("DYNAMIC INHERITANCE");
        DynamicCharacter dynamicCharacter = new DynamicCharacter();
        //FireSprite
        dynamicCharacter.changeCharacterType(CharacterTypeEnum.FireSprite);
        System.out.println(dynamicCharacter);
        //FireSiren
        dynamicCharacter.changeCharacterType(CharacterTypeEnum.FireSiren);
        System.out.println(dynamicCharacter);
        //InfernoDragon
        dynamicCharacter.changeCharacterType(CharacterTypeEnum.InfernoDragon);
        System.out.println(dynamicCharacter);
        System.out.println("------------------------------------------------");

        //Overlapping inheritance
        System.out.println("OVERLAPPING INHERITANCE");
        //start as Inferno Dragon
        OverlappingCharacter overlappingCharacter = new OverlappingCharacter(CharacterTypeEnum.InfernoDragon);
        System.out.println(overlappingCharacter);

        //add another type
        overlappingCharacter.addCharacterType(CharacterTypeEnum.Emberling);
        System.out.println(overlappingCharacter);
        System.out.println("------------------------------------------------");





        //Multi-aspect inheritance
        System.out.println("MULTI-ASPECT INHERITANCE");
        MultiaspectCharacter multiaspectCharacter = new MultiaspectCharacter(CharacterTypeEnum.FireSprite);
        System.out.println(multiaspectCharacter);

        //blazing aspect
        MultiaspectCharacterBlazing multiaspectCharacterBlazing = new MultiaspectCharacterBlazing("Blazing", 10);
        System.out.println(multiaspectCharacterBlazing);

        //fire aspect
        MultiaspectCharacterFire multiaspectCharacterFire = new MultiaspectCharacterFire("Fire", 15);
        System.out.println(multiaspectCharacterFire);
        System.out.println("------------------------------------------------");




        //Disjoint inheritance
        System.out.println("MULTI-ASPECT INHERITANCE");
        Mage mage = new Mage("Mage 1", 76, "sword", 8,90, "poison", 2);
        Archer archer = new Archer("Archer 1", 80, "legendary bow", 8, 88, 2);

        System.out.println(mage);
        System.out.println(archer);



        //Polymorphic method call
        System.out.println("POLYMORPHISM");
        System.out.println("Archer health before damage: " + archer.getHealth());
        mage.attack(archer);
        System.out.println("Archer health after damage: " + archer.getHealth());

        System.out.println("Mage health before damage: " + mage.getHealth());
        archer.attack(mage);
        System.out.println("Mage health after damage: " + mage.getHealth());
        System.out.println("------------------------------------------------");


        //Multi-inheritance
        System.out.println("MULTI-INHERITANCE");
        MultiInheritanceCharacter multiInheritanceCharacter = new MultiInheritanceCharacter("Multiinheritance Mage Archer", 100, "axe", 10, 100, "fire", 3, "Legendary", 3);

        //Testing attack
        System.out.println("Mage health before damage: " + mage.getHealth());
        multiInheritanceCharacter.attack(mage);
        System.out.println("Mage health after damage: " + mage.getHealth());

    }
}