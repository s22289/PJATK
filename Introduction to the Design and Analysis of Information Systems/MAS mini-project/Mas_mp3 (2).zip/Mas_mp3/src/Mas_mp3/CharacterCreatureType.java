package Mas_mp3;

public class CharacterCreatureType {
    private String name;
    private String gender;
    private String weaponType;
}
