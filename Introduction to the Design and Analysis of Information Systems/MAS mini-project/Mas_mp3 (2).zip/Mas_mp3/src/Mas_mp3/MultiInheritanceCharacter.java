package Mas_mp3;

public class MultiInheritanceCharacter extends Mage implements IArcher { //multi-inheritance, extends from Mage class and implements the IArcher interface
    private String category;
    private int numberOfArrowsPerAttack;

    public MultiInheritanceCharacter(String name, double strength, String weaponType, double hitDamage, double health, String specialSkill, double skillDamage, String category, int numberOfArrowsPerAttack) {
        super(name, strength, weaponType, hitDamage, health, specialSkill, skillDamage);
        this.category = category;
        this.numberOfArrowsPerAttack = numberOfArrowsPerAttack;
    }

    @Override
    public int getNumberOfArrowsPerAttack() {
        return numberOfArrowsPerAttack;
    }

    @Override
    public void multiplyArrows() {
        this.setHitDamage((this.getHitDamage() + this.getSkillDamage()) * getNumberOfArrowsPerAttack());
    }


}
