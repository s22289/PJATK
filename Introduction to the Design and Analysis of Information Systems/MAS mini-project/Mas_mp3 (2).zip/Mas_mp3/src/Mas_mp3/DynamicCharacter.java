package Mas_mp3;

import java.util.ArrayList;
import java.util.List;

class DynamicCharacter {
    private boolean canSpewFire;
    private boolean canScorch;
    private boolean canEngulf;
    private CharacterTypeEnum characterType;

    public boolean isCanSpewFire() {
        return canSpewFire;
    }

    public boolean isCanScorch() {
        return canScorch;
    }

    public boolean isCanEngulf() {
        return canEngulf;
    }

    public void setCharacterType(CharacterTypeEnum characterType) {
        this.characterType = characterType;
    }

    public CharacterTypeEnum getCharacterType() {
        return characterType;
    }

    public void changeCharacterType(CharacterTypeEnum characterType) {
        this.characterType = characterType;
        switch (characterType) {
            case FireSprite:
                canSpewFire = true;
                canScorch = true;
                canEngulf = false;
                break;
            case Emberling:
                canSpewFire = true;
                canScorch = true;
                canEngulf = false;
                break;
            case InfernoDragon:
                canSpewFire = true;
                canScorch = true;
                canEngulf = true;
                break;
            case FireSiren:
                canSpewFire = true;
                canScorch = false;
                canEngulf = false;
                break;
            default:
                break;
        }
    }

    public static DynamicCharacter getNewDynamicCharacter(CharacterTypeEnum characterType) {
        DynamicCharacter res = new DynamicCharacter();
        res.characterType = characterType;
        switch (characterType) {
            case FireSprite:
                res.canSpewFire = true;
                res.canScorch = true;
                res.canEngulf = false;
                break;
            case Emberling:
                res.canSpewFire = true;
                res.canScorch = true;
                res.canEngulf = false;
                break;
            case InfernoDragon:
                res.canSpewFire = true;
                res.canScorch = true;
                res.canEngulf = true;
                break;
            case FireSiren:
                res.canSpewFire = true;
                res.canScorch = false;
                res.canEngulf = false;
                break;
            default:
                break;
        }
        return res;
    }

    @Override
    public String toString() {
        return "Can spew fire: " + canSpewFire + ", Can scorch: " + canScorch + ", Can engulf: " + canEngulf;
    }
}

class OverlappingCharacter {
    private boolean canSpewFire;
    private boolean canScorch;
    private boolean canEngulf;
    private final List<CharacterTypeEnum> characterTypes;

    public OverlappingCharacter(CharacterTypeEnum type) {
        characterTypes = new ArrayList<>();
        characterTypes.add(type);
    }

    public boolean isCanSpewFire() {
        return canSpewFire;
    }

    public boolean isCanScorch() {
        return canScorch;
    }

    public boolean isCanEngulf() {
        return canEngulf;
    }

    public void addCharacterType(CharacterTypeEnum characterType) {
        if (!characterTypes.contains(characterType)) {
            characterTypes.add(characterType);
            switch (characterType) {
                case FireSprite:
                    canSpewFire = true;
                    canScorch = true;
                    break;
                case Emberling:
                    canSpewFire = true;
                    canScorch = true;
                    break;
                case InfernoDragon:
                    canSpewFire = true;
                    canScorch = true;
                    canEngulf = true;
                    break;
                case FireSiren:
                    canSpewFire = true;
                    break;
                default:
                    break;
            }
        }
    }

    public void removeCharacterType(CharacterTypeEnum characterType) {
        if (characterTypes.contains(characterType)) {
            switch (characterType) {
                case FireSprite:
                    if (!characterTypes.contains(CharacterTypeEnum.Emberling))
                        canScorch = false;
                    break;
                case Emberling:
                    if (!characterTypes.contains(CharacterTypeEnum.FireSprite))
                        canScorch = false;
                    break;
                case InfernoDragon:
                    if (!characterTypes.contains(CharacterTypeEnum.FireSiren))
                        canEngulf = false;
                    break;
                case FireSiren:
                    if (!characterTypes.contains(CharacterTypeEnum.InfernoDragon))
                        canEngulf = false;
                    break;
                default:
                    break;
            }
        } else {
            throw new IllegalArgumentException("Character doesn't include this type");
        }
    }

    @Override
    public String toString() {
        return "Can spew fire: " + canSpewFire + ", Can scorch: " + canScorch + ", Can engulf: " + canEngulf;
    }
}