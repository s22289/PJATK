package Mas_mp3;

public interface IArcher {
    int getNumberOfArrowsPerAttack();
    void multiplyArrows();
}
