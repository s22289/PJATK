package Mas_mp3;

public class Character {
    private String name;
    private double strength;
    private String weaponType;
    private double hitDamage;
    private double health;

    private static final double maxHealth = 100;

    public Character(String name, double strength, String weaponType, double hitDamage, double health) {
        this.name = name;
        this.strength = strength;
        this.weaponType = weaponType;
        this.hitDamage = hitDamage;
        this.health = health;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getStrength() {
        return strength;
    }

    public void setStrength(double strength) {
        this.strength = strength;
    }

    public String getWeaponType() {
        return weaponType;
    }

    public void setWeaponType(String weaponType) {
        this.weaponType = weaponType;
    }

    public double getHitDamage() {
        return hitDamage;
    }

    public void setHitDamage(double hitDamage) {
        this.hitDamage = hitDamage;
    }

    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = health;
    }

    public void attack(Character character){
        character.takeDamage(this.hitDamage);
    }

    public void takeDamage(double hitDamage) {
        this.health -= hitDamage;
    }
}
