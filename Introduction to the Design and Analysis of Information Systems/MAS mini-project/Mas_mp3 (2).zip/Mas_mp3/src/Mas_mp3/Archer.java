package Mas_mp3;

public class Archer extends Character { //disjoint inheritance to Character
    private int numberOfArrowsPerAttack;


    public Archer(String name, double strength, String weaponType, double hitDamage, double health, int numberOfArrowsPerAttack) {
        super(name, strength, weaponType, hitDamage, health);
        this.numberOfArrowsPerAttack = numberOfArrowsPerAttack;
    }

    //Polymorphism - abstract method call
    @Override
    public void attack(Character character) {
        double finalDamage = numberOfArrowsPerAttack * this.getHitDamage();
        character.takeDamage(finalDamage);
    }

    @Override
    public String toString() {
        return "Archer{" +
                "numberOfArrowsPerAttack=" + numberOfArrowsPerAttack +
                '}';
    }
}
