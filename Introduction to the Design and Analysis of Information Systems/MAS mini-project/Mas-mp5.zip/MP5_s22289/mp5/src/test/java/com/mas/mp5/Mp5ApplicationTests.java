package com.mas.mp5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mp5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
