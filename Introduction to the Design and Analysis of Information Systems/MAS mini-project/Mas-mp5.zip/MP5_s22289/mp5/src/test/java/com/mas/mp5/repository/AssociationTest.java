package com.mas.mp5.repository;

import com.mas.mp5.model.Part;
import com.mas.mp5.model.Warehouse;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
public class AssociationTest {
    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    private PartRepository partRepository;

    @Autowired
    private WarehouseRepository warehouseRepository;

    Part p1;
    Warehouse w1;

    @Test
    public void testRequiredDependencies(){
        assertNotNull(partRepository);
        assertNotNull(warehouseRepository);
    }

    @BeforeEach
    public void init(){
        p1 = Part.builder().code("XZ20")
                .name("Partxz20")
                .quantity(100)
                .cost(28)
                .build();
        w1 = Warehouse.builder().code("WAW")
                .name("Warsaw Branch")
                .location("Warsaw, Poland")
                .build();
    }

    @Test
    public void testSave(){
        w1.getParts().add(p1);
        warehouseRepository.save(w1);
        p1.setWarehouse(w1);
        partRepository.save(p1);

        Optional<Warehouse> byId = warehouseRepository.findById(w1.getId());
        assertNotNull(byId);
        assertTrue(byId.isPresent());
        System.out.println(byId.get().getParts());
        assertEquals(1, byId.get().getParts().size());
    }
}
