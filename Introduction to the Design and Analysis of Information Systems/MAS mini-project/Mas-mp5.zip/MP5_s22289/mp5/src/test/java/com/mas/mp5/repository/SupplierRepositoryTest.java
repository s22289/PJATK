package com.mas.mp5.repository;

import com.mas.mp5.model.Distributor;
import com.mas.mp5.model.Manufacturer;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.shadow.com.univocity.parsers.common.input.LineSeparatorDetector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class SupplierRepositoryTest {

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private DistributorRepository distributorRepository;

    @Autowired
    private ManufacturerRepository manufacturerRepository;

    Distributor d1, d2;
    Manufacturer m1;

    @BeforeEach
    public void init(){
        d1 = Distributor.builder().name("OBI")
                .contact("1234212")
                .orderFee(23.99)
                .minimumOrderQuantity(30)
                .build();
        d2 = Distributor.builder().name("UNIV")
                .contact("8679102")
                .orderFee(16.5)
                .minimumOrderQuantity(30)
                .build();
        m1 = Manufacturer.builder().name("Pasha")
                .contact("+99922323")
                .orderFee(10.99)
                .productCustomizationAllowed(false)
                .productExpenses(0)
                .build();
    }

    @Test
    public void testRequiredDependencies(){
        assertNotNull(supplierRepository);
        assertNotNull(distributorRepository);
        assertNotNull(manufacturerRepository);
    }

    @Test
    public void testSaveAll(){
        distributorRepository.saveAll(Arrays.asList(d1,d2));
        manufacturerRepository.save(m1);
        entityManager.flush();
        assertEquals(3,supplierRepository.count());
    }

}