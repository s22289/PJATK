package com.mas.mp5.repository;

import com.mas.mp5.model.Part;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.validation.ConstraintViolationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class PartRepositoryTest {

    @Autowired
    private PartRepository partRepository;

    @PersistenceContext
    private EntityManager entityManager;

    Part p1;

    @BeforeEach
    public void init(){
        p1 = Part.builder().code("P003")
                .name("NewPart")
                .quantity(3)
                .cost(2.7)
                .build();
    }

    @Test
    public void testRequiredDependencies(){
        assertNotNull(partRepository);
    }

    @Test
    public void testFetchParts(){
        Iterable<Part> all = partRepository.findAll();
        for (Part p : all){
            System.out.println(p);
        }
    }

    @Test
    public void testSaveDatabase(){
        partRepository.save(p1);
        entityManager.flush();
        long count = partRepository.count();
        assertEquals(1, count);
    }

    @Test
    public void testInvalidPartCost(){
        assertThrows(ConstraintViolationException.class, ()->{
            p1.setCost(-928);
            partRepository.save(p1);
            entityManager.flush();
        });
    }

    @Test
    public void testFindByCode(){
        List<Part> p001 = partRepository.findByCode("P001");
        assertEquals(1, p001.size());
    }

    @Test
    public void testFindByCodeAndCost(){
        List<Part> p001 = partRepository.findByCodeAndCost("P001", 10);
        assertEquals(1, p001.size());
    }

    @Test
    public void testFindNonStockedParts(){
        List<Part> p001 = partRepository.findNonStockedParts();
        assertEquals(1, p001.size());
        assertEquals(0,p001.get(0).getQuantity());
    }
}