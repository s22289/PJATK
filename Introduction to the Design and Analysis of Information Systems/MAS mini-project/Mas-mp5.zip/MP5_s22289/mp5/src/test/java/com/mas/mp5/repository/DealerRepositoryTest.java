package com.mas.mp5.repository;

import com.mas.mp5.model.Dealer;
import com.mas.mp5.model.Part;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class DealerRepositoryTest {
    @Autowired
    private DealerRepository dealerRepository;

    @PersistenceContext
    private EntityManager entityManager;

    Dealer d1;

    @BeforeEach
    public void init(){
        d1 = Dealer.builder().code("0001")
                .brandingName("AAA")
                .address("Warsaw, Poland")
                .build();
    }

    @Test
    public void testRequiredDependencies(){
        assertNotNull(dealerRepository);
    }

    @Test
    public void testFindByCode(){
        List<Dealer> dealerList = dealerRepository.findByCode("0001");
        assertEquals(1, dealerList.size());
    }


}