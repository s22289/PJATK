package com.mas.mp5.model;

import jakarta.persistence.Entity;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Entity // Indicates that this is a JPA entity
@Data // Lombok annotation to generate getters, setters, toString, equals, and hashCode methods
@NoArgsConstructor // Lombok annotation to generate a no-argument constructor
@AllArgsConstructor // Lombok annotation to generate an all-argument constructor
@SuperBuilder // Lombok annotation to implement the builder pattern, supporting inheritance
public class Distributor extends Supplier {

    @Min(1) // Validation annotation to ensure this field has a minimum value of 1
    private int minimumOrderQuantity;
}
