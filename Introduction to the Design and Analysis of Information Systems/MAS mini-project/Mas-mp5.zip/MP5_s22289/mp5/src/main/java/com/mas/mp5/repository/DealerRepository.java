package com.mas.mp5.repository;

import com.mas.mp5.model.Dealer;
import com.mas.mp5.model.Warehouse;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DealerRepository extends CrudRepository<Dealer, Long> {

    // Method to find dealers by their code
    List<Dealer> findByCode(String code);

    // Custom query to fetch a dealer by ID along with their warehouses using a left join
    @Query("from Dealer as d left join fetch d.warehouses where d.id = :id")
    Optional<Dealer> findById(@Param("id") Long id);
}
