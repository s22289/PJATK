package com.mas.mp5.repository;

import com.mas.mp5.model.Part;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PartRepository extends CrudRepository<Part, Long> {

    List<Part> findByCode(String code);
    List<Part> findByCodeAndCost(String code, double cost);

    @Query("from Part where quantity = 0")
    List<Part> findNonStockedParts();

}
