package com.mas.mp5.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Warehouse {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) // Specifies the primary key generation strategy
    private long id;

    @ManyToOne(optional = false) // Specifies a many-to-one relationship with the Dealer entity
    @JoinColumn(name = "owner_id", nullable = false, updatable = false) // Defines the foreign key column for the owner
    private Dealer owner;

    @NotBlank(message = "Code must exist") // Validation annotation to ensure this field is not null or blank
    private String code;

    @NotBlank(message = "Name must exist") // Validation annotation to ensure this field is not null or blank
    private String name;

    @NotBlank(message = "Location must exist") // Validation annotation to ensure this field is not null or blank
    @Size(min = 3, max = 55) // Validation annotation to ensure this field's size is between 3 and 55 characters
    private String location;

    @OneToMany(mappedBy = "warehouse", fetch = FetchType.LAZY) // Specifies a one-to-many relationship with the Part entity
    @Builder.Default // Ensures the default value is used for the parts field when using the builder pattern
    @ToString.Exclude // Excludes parts from the generated toString method to prevent infinite recursion
    @EqualsAndHashCode.Exclude // Excludes parts from the generated equals and hashCode methods to prevent potential issues
    private Set<Part> parts = new HashSet<>(); // A set of parts associated with this warehouse
}
