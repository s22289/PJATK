package com.mas.mp5.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.sql.init.dependency.DependsOnDatabaseInitialization;

import java.time.LocalDate;
import java.util.Set;

@Entity // Indicates that this is a JPA entity
@Data // Lombok annotation to generate getters, setters, toString, equals, and hashCode methods
@NoArgsConstructor // Lombok annotation to generate a no-argument constructor
@AllArgsConstructor // Lombok annotation to generate an all-argument constructor
@Builder // Lombok annotation to implement the builder pattern
@ToString // Lombok annotation to generate a toString method
public class Part {

    @Id // Marks this field as the primary key
    @GeneratedValue(strategy = GenerationType.AUTO) // Specifies the generation strategy for the primary key
    private long id;

    @NotBlank(message = "Code must exist") // Validation annotation to ensure this field is not null or blank
    private String code;

    @NotBlank(message = "Name must exist") // Validation annotation to ensure this field is not null or blank
    private String name;

    @Min(0) // Validation annotation to ensure this field has a minimum value of 0
    private int quantity;

    @Min(0) // Validation annotation to ensure this field has a minimum value of 0
    private double cost;

    @ElementCollection // Specifies a collection of basic or embeddable types
    @CollectionTable(name = "part_material", joinColumns = @JoinColumn(name = "part_id")) // Maps the collection of materials to a separate table
    @ToString.Exclude // Excludes materials from the generated toString method to prevent infinite recursion
    @EqualsAndHashCode.Exclude // Excludes materials from the generated equals and hashCode methods to prevent potential issues
    private Set<String> materials; // A set of materials associated with this part

    @ManyToOne // Specifies a many-to-one relationship with the Warehouse entity
    @JoinColumn(name = "warehouse_id") // Specifies the foreign key column
    @EqualsAndHashCode.Exclude // Excludes warehouse from the generated equals and hashCode methods to prevent potential issues
    private Warehouse warehouse; // The warehouse where this part is stored

    @OneToMany(mappedBy = "part", cascade = CascadeType.REMOVE) // Specifies a one-to-many relationship with the PartSupply entity
    @ToString.Exclude // Excludes partSupplies from the generated toString method to prevent infinite recursion
    @EqualsAndHashCode.Exclude // Excludes partSupplies from the generated equals and hashCode methods to prevent potential issues
    private Set<PartSupply> partSupplies; // A set of part supplies associated with this part
}
