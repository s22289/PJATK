package com.mas.mp5.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.Set;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Inheritance(strategy = InheritanceType.JOINED) // Strategy for inheritance mapping in JPA
@SuperBuilder // Lombok annotation to implement the builder pattern, supporting inheritance
public abstract class Supplier {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) // Specifies the primary key generation strategy
    private long id;

    @NotBlank(message = "Name must exist") // Validation annotation to ensure this field is not null or blank
    private String name;

    private String contact;

    @Min(0) // Validation annotation to ensure this field has a minimum value of 0
    private double orderFee;

    @OneToMany(mappedBy = "supplier", cascade = CascadeType.REMOVE) // Specifies a one-to-many relationship with the PartSupply entity
    @ToString.Exclude // Excludes partSupplies from the generated toString method to prevent infinite recursion
    @EqualsAndHashCode.Exclude // Excludes partSupplies from the generated equals and hashCode methods to prevent potential issues
    private Set<PartSupply> partSupplies; // A set of part supplies associated with this supplier
}
