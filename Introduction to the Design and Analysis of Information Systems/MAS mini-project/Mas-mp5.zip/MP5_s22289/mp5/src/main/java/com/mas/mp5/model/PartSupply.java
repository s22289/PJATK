package com.mas.mp5.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(uniqueConstraints = {
        @UniqueConstraint(columnNames = {"part_id", "supplier_id"}) // Ensures the combination of part_id and supplier_id is unique
})
public class PartSupply {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) // Specifies the primary key generation strategy
    private long id;

    @ManyToOne
    @JoinColumn(name = "part_id", nullable = false) // Foreign key to the Part entity
    @NotNull // Ensures the part is not null
    private Part part;

    @ManyToOne
    @JoinColumn(name = "supplier_id", nullable = false) // Foreign key to the Supplier entity
    @NotNull // Ensures the supplier is not null
    private Supplier supplier;

    @Min(1) // Ensures the quantity has a minimum value of 1
    private int quantity;

    @NotNull // Ensures the date is not null
    private LocalDate date;
}
