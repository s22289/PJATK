package com.mas.mp5.repository;

import com.mas.mp5.model.Manufacturer;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface ManufacturerRepository extends CrudRepository<Manufacturer, Long> {
    @Query("from Manufacturer where productCustomizationAllowed = false")
    List<Manufacturer> findByProductCustomizationAllowedFalse();

}
