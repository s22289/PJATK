package com.mas.mp5;

import com.mas.mp5.model.Part;
import com.mas.mp5.repository.PartRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer {

    private final PartRepository partRepository;

    // Listener method triggered when the application context is refreshed
    @EventListener
    public void atStart(ContextRefreshedEvent ev){
        System.out.println("context refreshed"); // Prints a message indicating the context refresh event
        Iterable<Part> nonStocked = partRepository.findNonStockedParts(); // Fetches non-stocked parts
        System.out.println(nonStocked); // Prints non-stocked parts
    }
}
