package com.mas.mp5.model;

import com.mas.mp5.model.Part;
import com.mas.mp5.model.Warehouse;
import com.mas.mp5.repository.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;

import com.mas.mp5.model.Dealer;
import java.util.List;
import jakarta.validation.ConstraintViolationException;
import com.mas.mp5.model.Distributor;
import com.mas.mp5.model.Manufacturer;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {

        // Test class for testing database associations
        @DataJpaTest
        class AssociationTest {
            @PersistenceContext
            EntityManager entityManager;

            @Autowired
            private PartRepository partRepository;

            @Autowired
            private WarehouseRepository warehouseRepository;

            Part p1;
            Warehouse w1;

            // Method to test if required dependencies are injected
            @Test
            public void testRequiredDependencies() {
                assertNotNull(partRepository);
                assertNotNull(warehouseRepository);
            }

            // Method to initialize data before each test
            @BeforeEach
            public void init() {
                p1 = Part.builder().code("XZ20")
                        .name("Partxz20")
                        .quantity(100)
                        .cost(28)
                        .build();
                w1 = Warehouse.builder().code("WAW")
                        .name("Warsaw Branch")
                        .location("Warsaw, Poland")
                        .build();
            }

            // Method to test saving and fetching entities
            @Test
            public void testSave() {
                w1.getParts().add(p1);
                warehouseRepository.save(w1);
                p1.setWarehouse(w1);
                partRepository.save(p1);

                Optional<Warehouse> byId = warehouseRepository.findById(w1.getId());
                assertNotNull(byId);
                assertTrue(byId.isPresent());
                System.out.println(byId.get().getParts());
                assertEquals(1, byId.get().getParts().size());
            }
        }

        // Test class for testing Dealer repository
        @DataJpaTest
        class DealerRepositoryTest {
            @Autowired
            private DealerRepository dealerRepository;

            @PersistenceContext
            private EntityManager entityManager;

            Dealer d1;

            // Method to initialize data before each test
            @BeforeEach
            public void init() {
                d1 = Dealer.builder().code("0001")
                        .brandingName("AAA")
                        .address("Warsaw, Poland")
                        .build();
            }

            // Method to test if required dependencies are injected
            @Test
            public void testRequiredDependencies() {
                assertNotNull(dealerRepository);
            }

            // Method to test finding dealers by code
            @Test
            public void testFindByCode() {
                List<Dealer> dealerList = dealerRepository.findByCode("0001");
                assertEquals(1, dealerList.size());
            }
        }

        // Test class for testing Part repository
        @DataJpaTest
        class PartRepositoryTest {
            @Autowired
            private PartRepository partRepository;

            @PersistenceContext
            private EntityManager entityManager;

            Part p1;

            // Method to initialize data before each test
            @BeforeEach
            public void init() {
                p1 = Part.builder().code("P003")
                        .name("NewPart")
                        .quantity(3)
                        .cost(2.7)
                        .build();
            }

            // Method to test if required dependencies are injected
            @Test
            public void testRequiredDependencies() {
                assertNotNull(partRepository);
            }

            // Method to test fetching all parts
            @Test
            public void testFetchParts() {
                Iterable<Part> all = partRepository.findAll();
                for (Part p : all) {
                    System.out.println(p);
                }
            }

            // Method to test saving part to the database
            @Test
            public void testSaveDatabase() {
                partRepository.save(p1);
                entityManager.flush();
                long count = partRepository.count();
                assertEquals(1, count);
            }

            // Method to test handling invalid part cost
            @Test
            public void testInvalidPartCost() {
                assertThrows(ConstraintViolationException.class, () -> {
                    p1.setCost(-928);
                    partRepository.save(p1);
                    entityManager.flush();
                });
            }

            // Method to test finding parts by code
            @Test
            public void testFindByCode() {
                List<Part> p001 = partRepository.findByCode("P001");
                assertEquals(1, p001.size());
            }

            // Method to test finding parts by code and cost
            @Test
            public void testFindByCodeAndCost() {
                List<Part> p001 = partRepository.findByCodeAndCost("P001", 10);
                assertEquals(1, p001.size());
            }

            // Method to test finding non-stocked parts
            @Test
            public void testFindNonStockedParts() {
                List<Part> p001 = partRepository.findNonStockedParts();
                assertEquals(1, p001.size());
                assertEquals(0, p001.get(0).getQuantity());
            }
        }

        // Test class for testing Supplier repository
        @DataJpaTest
        class SupplierRepositoryTest {

            @PersistenceContext
            EntityManager entityManager;

            @Autowired
            private SupplierRepository supplierRepository;

            @Autowired
            private DistributorRepository distributorRepository;

            @Autowired
            private ManufacturerRepository manufacturerRepository;

            Distributor d1, d2;
            Manufacturer m1;

            // Method to initialize data before each test
            @BeforeEach
            public void init() {
                d1 = Distributor.builder().name("OBI")
                        .contact("1234212")
                        .orderFee(23.99)
                        .minimumOrderQuantity(30)
                        .build();
                d2 = Distributor.builder().name("UNIV")
                        .contact("8679102")
                        .orderFee(16.5)
                        .minimumOrderQuantity(30)
                        .build();
                m1 = Manufacturer.builder().name("Pasha")
                        .contact("+99922323")
                        .orderFee(10.99)
                        .productCustomizationAllowed(false)
                        .productExpenses(0)
                        .build();
            }

            // Method to test if required dependencies are injected
            @Test
            public void testRequiredDependencies() {
                assertNotNull(supplierRepository);
                assertNotNull(distributorRepository);
                assertNotNull(manufacturerRepository);
            }

            // Method to test saving all types of suppliers
            @Test
            public void testSaveAll() {
                distributorRepository.saveAll(Arrays.asList(d1, d2));
                manufacturerRepository.save(m1);
                entityManager.flush();
                assertEquals(3, supplierRepository.count());
            }
        }
    }
}