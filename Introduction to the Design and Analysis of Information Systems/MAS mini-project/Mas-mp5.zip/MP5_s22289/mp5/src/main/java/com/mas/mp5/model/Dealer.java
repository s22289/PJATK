package com.mas.mp5.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.Set;

@Entity // Indicates that this is a JPA entity
@Data // Lombok annotation to generate getters, setters, toString, equals, and hashCode methods
@NoArgsConstructor // Lombok annotation to generate a no-argument constructor
@AllArgsConstructor // Lombok annotation to generate an all-argument constructor
@Builder // Lombok annotation to implement the builder pattern
@ToString // Lombok annotation to generate a toString method
public class Dealer {

    @Id // Marks this field as the primary key
    @GeneratedValue(strategy = GenerationType.AUTO) // Specifies the generation strategy for the primary key
    private long id;

    @NotBlank // Validation annotation to ensure this field is not null or blank
    private String code;

    @NotBlank // Validation annotation to ensure this field is not null or blank
    private String brandingName;

    @NotBlank // Validation annotation to ensure this field is not null or blank
    private String address;

    @OneToMany(mappedBy = "owner", cascade = CascadeType.REMOVE) // Specifies a one-to-many relationship with the Warehouse entity
    @ToString.Exclude // Excludes warehouses from the generated toString method to prevent infinite recursion
    @EqualsAndHashCode.Exclude // Excludes warehouses from the generated equals and hashCode methods to prevent potential issues
    private Set<Warehouse> warehouses; // A set of warehouses associated with this dealer

}
