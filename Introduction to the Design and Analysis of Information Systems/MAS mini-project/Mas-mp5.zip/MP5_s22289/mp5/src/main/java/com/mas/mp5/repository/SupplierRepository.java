package com.mas.mp5.repository;

import com.mas.mp5.model.Part;
import com.mas.mp5.model.Supplier;
import com.mas.mp5.model.Warehouse;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface SupplierRepository extends CrudRepository<Supplier, Long> {
    List<Supplier> findByName(String name);
}
