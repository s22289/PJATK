package com.mas.mp5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mp5Application {

    public static void main(String[] args) {
        SpringApplication.run(Mp5Application.class, args);
    }

}
