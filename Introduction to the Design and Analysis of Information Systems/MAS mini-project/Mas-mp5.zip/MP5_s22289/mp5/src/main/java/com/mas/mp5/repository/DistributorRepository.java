package com.mas.mp5.repository;

import com.mas.mp5.model.Distributor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DistributorRepository extends CrudRepository<Distributor, Long> {

    @Query("from Distributor where minimumOrderQuantity > :min_quantity")
    Optional<Distributor> findDistributorsWithMinimumOrderQuantityLessThan(@Param("min_quantity") int minQuantity);
}
