package com.mas.mp5.repository;

import com.mas.mp5.model.Warehouse;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface WarehouseRepository extends CrudRepository<Warehouse, Long> {
    List<Warehouse> findByCode(String code);

    @Query("from Warehouse as w left join fetch w.parts where w.id = :id")
    Optional<Warehouse> findById(@Param("id") Long id);
}
